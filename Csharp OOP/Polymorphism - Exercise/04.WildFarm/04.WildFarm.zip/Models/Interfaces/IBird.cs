﻿namespace WildFarm.Models.Interfaces
{
    public interface IBird : IAnimal
    {
        public double WingSize { get; }
    }
}
