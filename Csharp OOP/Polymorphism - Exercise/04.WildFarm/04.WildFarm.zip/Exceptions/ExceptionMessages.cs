﻿namespace WildFarm.Exceptions
{
    public class ExceptionMessages
    {
        public const string InvalidFood = "{0} does not eat {1}!";
        public const string InvalidFoodType = "Invalid Food Type";
        public const string InvalidAnimalType = "Invalid Animal Type";

    }
}
