﻿namespace Vehicles.Core.Interafaces
{
    public interface IEngine
    {
        public void Run();
    }
}
