﻿namespace Raiding.Exceptions
{
    public class ExceptionMessages
    {
        public const string InvalidType = "Invalid hero!";
    }
}
