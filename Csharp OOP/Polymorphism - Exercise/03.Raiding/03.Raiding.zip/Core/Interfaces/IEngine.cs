﻿namespace Raiding.Core.Interfaces
{
    interface IEngine
    {
        public void Run();
    }
}
