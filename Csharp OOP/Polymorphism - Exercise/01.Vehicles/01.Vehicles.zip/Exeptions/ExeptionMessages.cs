﻿namespace Vehicles.Exeptions
{
    public class ExeptionMessages
    {
        public const string InsufficientFuelExeption = "{0} needs refueling";
    }
}
