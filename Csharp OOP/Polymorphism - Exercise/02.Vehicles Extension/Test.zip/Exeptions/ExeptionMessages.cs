﻿namespace Vehicles.Exeptions
{
    public class ExeptionMessages
    {
        public const string InsufficientFuelExeption = "{0} needs refueling";
        public const string NoCapacityFuelExeption = "Cannot fit {0} fuel in the tank";
        public const string InvalidFuelExeption = "Fuel must be a positive number";
    }
}
