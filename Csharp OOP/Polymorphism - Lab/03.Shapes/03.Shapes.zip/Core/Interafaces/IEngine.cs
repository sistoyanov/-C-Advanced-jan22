﻿namespace Shapes.Core.Interafaces
{
    public interface IEngine
    {
        public void Run();
    }
}
