﻿namespace Shapes.IO.Interfaces
{
    public interface IReader
    {
        public void ReadLine(string text);
    }
}
