﻿using Animals.IO.Interfaces;

namespace Animals.Core.Interfaces
{
    public interface IEngine
    {
        public void Run();
    }
}
