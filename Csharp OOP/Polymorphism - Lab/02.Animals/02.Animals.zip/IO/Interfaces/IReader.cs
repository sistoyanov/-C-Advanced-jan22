﻿namespace Animals.IO.Interfaces
{
    public interface IReader
    {
        public void ReadLine(string text);
    }
}
