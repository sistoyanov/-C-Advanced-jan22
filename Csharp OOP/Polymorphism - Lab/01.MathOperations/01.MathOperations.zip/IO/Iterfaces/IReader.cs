﻿namespace Operations.IO.Iterfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
