﻿namespace Operations.IO.Iterfaces
{
    public interface IWriter
    {
        public void Write(string text);

        public void WriteLine(string text);

    }
}
