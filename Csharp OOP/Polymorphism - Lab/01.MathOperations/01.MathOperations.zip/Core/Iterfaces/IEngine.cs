﻿namespace Operations.Core.Iterfaces
{
    public interface IEngine
    {
        void Run();
    }
}
