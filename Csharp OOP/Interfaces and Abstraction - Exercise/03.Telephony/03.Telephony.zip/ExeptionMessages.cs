﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public static class ExeptionMessages
    {
        public const string InvalidNumberMessage = "Invalid number!";
        public const string InvalidUrlMessage = "Invalid URL!";
    }
}
