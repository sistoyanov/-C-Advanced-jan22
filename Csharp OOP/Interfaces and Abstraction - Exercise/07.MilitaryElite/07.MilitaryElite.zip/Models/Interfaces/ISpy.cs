﻿namespace MilitaryElite.Models.Interfaces
{
    public interface ISpy : ISoldier
    {
        public int CodeNumber { get; }
    }
}
