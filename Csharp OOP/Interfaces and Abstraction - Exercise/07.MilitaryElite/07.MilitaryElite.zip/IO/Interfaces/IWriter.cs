﻿namespace MilitaryElite.IO.Interfaces
{
     public interface IWriter
    {
        void Wite(string text);

        void WriteLine(string text);
    }
}
