﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebration
{ 
    public interface IControlable
    {
        public string Id { get; set; }
    }
}
