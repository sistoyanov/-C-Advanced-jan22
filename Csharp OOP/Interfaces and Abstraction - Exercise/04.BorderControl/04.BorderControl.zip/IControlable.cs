﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IControlable
    {
        public string Id { get; set; }
    }
}
