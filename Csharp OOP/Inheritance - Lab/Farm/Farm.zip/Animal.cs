﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace Farm
{
    public class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating…");
        }
    }
}
