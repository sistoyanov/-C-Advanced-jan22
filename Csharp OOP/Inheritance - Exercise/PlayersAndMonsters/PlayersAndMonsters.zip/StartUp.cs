﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Hero hero = new Hero("Gosho", 6);
            System.Console.WriteLine(hero);
        }
    }
}