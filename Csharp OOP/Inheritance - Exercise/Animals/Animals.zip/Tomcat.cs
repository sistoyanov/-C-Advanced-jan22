﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animals
{
    public class Tomcat : Cat
    {
        //private string gender;
        public Tomcat(string name, int age) : base(name, age, "Male")
        {
            //gender = "Male";
        }

        //public override string Gender { get => gender; }

        public override string ProduceSound()
        {
            return "MEOW";
        }
    }
}
