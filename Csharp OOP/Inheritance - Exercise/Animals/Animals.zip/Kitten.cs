﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animals
{
    public class Kitten : Cat
    {
        //private string gender;
        public Kitten(string name, int age) : base(name, age, "Female")
        {
           // gender = "Female";
        }

        //public override string Gender { get => gender; }

        public override string ProduceSound()
        {
            return "Meow";
        }
    }
}
