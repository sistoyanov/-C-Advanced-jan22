﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Restaurant
{
    public class Cake : Dessert
    {
        private const double DESSERT_GRAMS = 250;
        private const double DESSERT_CALORIES = 1000;
        private const decimal DESSERT_PRICE = 5m;
        public Cake(string name) : base(name, DESSERT_PRICE, DESSERT_GRAMS, DESSERT_CALORIES)
        {
            //this.grams = 250;
            //this.calories = 1000;
            //this.price = 5m;
        }

        //public override double Grams { get => grams; }
        //public override double Calories { get => calories; }
        //public override decimal Price { get => price; }

    }
}
