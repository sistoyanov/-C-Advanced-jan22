﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassBoxData
{
    public class Box
	{
		private double length;
        private double width;
        private double height;

		public Box(double length, double width, double height)
		{
			this.Length = length;
			this.Width = width;
			this.Height = height;
		}

        public double Length
        {
			get { return length; }
			set 
			{
				if (value <= 0)
				{
					throw new ArgumentException("Length cannot be zero or negative.");
				}

				length = value; 
			}
		}

		public double Width
        {	
			get { return width; }
			set 
			{
                if (value <= 0)
                {
                    throw new ArgumentException("Width cannot be zero or negative.");
                }

                width = value; 
			}
		}

		public double Height
        {
			get { return height; }
			set 
			{
                if (value <= 0)
                {
                    throw new ArgumentException("Height cannot be zero or negative.");
                }

                height = value; 
			}
		}

		public double SurfaceArea()
		{
			double surfaceArea = (2 * length * width) + (2 * length * height) + (2 * width * height);
			return surfaceArea; //Math.Round(surfaceArea, 2);
		}

		public double LateralSurfaceArea()
		{
			double lateralSurfaceArea = (2 * length * height) + (2 * width * height);
			return lateralSurfaceArea; //Math.Round(lateralSurfaceArea, 2);
		}

		public double Volume()
		{
			double volume = length * width * height;
			return volume; //Math.Round(volume, 2);
		}
    }
}
