﻿
namespace EasterRaces.Repositories.Entities
{
    using Models.Drivers.Contracts;
    public class DriverRepository : Repository<IDriver>
    {
    }
}
