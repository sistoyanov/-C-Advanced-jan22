﻿
namespace EasterRaces.Repositories.Entities
{
    using Models.Cars.Contracts;
    public class CarRepository : Repository<ICar>
    {

    }
}
