﻿
namespace EasterRaces.Repositories.Entities
{
    using Models.Races.Contracts;
    public class RaceRepository : Repository<IRace>
    {
    }
}
