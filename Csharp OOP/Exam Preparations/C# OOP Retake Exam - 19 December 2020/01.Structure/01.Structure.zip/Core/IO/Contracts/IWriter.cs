﻿namespace WarCroft.Core.IO.Contracts
{
	public interface IWriter
	{
		void WriteLine(string message);
	}
}
