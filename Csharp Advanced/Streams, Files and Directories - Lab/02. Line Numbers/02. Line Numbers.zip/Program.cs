﻿using System;
using System.IO;
using System.Linq;

namespace LineNumbers
{
    public class LineNumbers
    {
        static void Main()
        {
            string inputPath = @"..\..\..\Files\input.txt";
            string outputPath = @"..\..\..\Files\output.txt";

            RewriteFileWithLineNumbers(inputPath, outputPath);
        }

        public static void RewriteFileWithLineNumbers(string inputFilePath, string outputFilePath)
        {
            //tring output = String.Empty;
            StreamReader reader = new StreamReader(inputFilePath);
            StreamWriter writer = new StreamWriter(outputFilePath);

            using (reader)
            {
                int counter = 0;
                string line = String.Empty;  //reader.ReadLine();

                using (writer)
                {
                while ((line = reader.ReadLine()) != null)
                {
                        counter++;
                        writer.WriteLine($"{counter}. {line}");


                        //if (counter % 2 == 0)
                        //{
                        //string[] currentWords = line.Split(' ');
                        //currentWords = currentWords.Reverse().ToArray();

                        //for (int i = 0; i < currentWords.Length; i++)
                        //{
                        //    currentWords[i] = currentWords[i].Replace('-', '@').Replace(',', '@').Replace('.', '@').Replace('!', '@').Replace('?', '@');
                        //}


                        //output += (String.Join(" ", currentWords));
                        //}


                        //line = reader.ReadLine();
                    }

                }

            }

            //return output;
        }
    }
}
